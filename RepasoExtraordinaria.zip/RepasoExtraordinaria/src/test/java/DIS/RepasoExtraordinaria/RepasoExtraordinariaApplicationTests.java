package DIS.RepasoExtraordinaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RepasoExtraordinariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
