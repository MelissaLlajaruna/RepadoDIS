package DIS.RepasoExtraordinaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RepasoExtraordinariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RepasoExtraordinariaApplication.class, args);
	}

}
